package com.example.swagerdemo.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class HelloController 
{

@GetMapping("/api/hello")
public String getMessage()
{
	return "Hello World User";
}
@GetMapping("/api/hello/{username}")
public String getMessageUserid(@PathVariable String username)
{
	return "Hello World " + username;
}
}
